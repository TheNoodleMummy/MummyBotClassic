﻿namespace Espeon.Core.Services
{
    public interface ICustomCommandsService
    {
    }
}
