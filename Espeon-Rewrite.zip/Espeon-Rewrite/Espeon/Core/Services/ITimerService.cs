﻿namespace Espeon.Core.Services
{
    public interface ITimerService
    {
    }
}
