﻿namespace Espeon.Core.Services
{
    public interface IMessageService
    {
    }
}
