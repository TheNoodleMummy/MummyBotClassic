namespace Victoria
{
    public struct Endpoint
    {
        public int Port { internal get; set; }
        public string Host { internal get; set; }
    }
}