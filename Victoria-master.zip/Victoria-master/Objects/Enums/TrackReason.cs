namespace Victoria.Objects.Enums
{
    public enum TrackReason
    {
        Finished,
        LoadFailed,
        Stopped,
        Replaced,
        Cleanup
    }
}