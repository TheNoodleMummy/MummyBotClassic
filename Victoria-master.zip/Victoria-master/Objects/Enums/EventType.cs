namespace Victoria.Objects.Enums
{
    internal enum EventType
    {
        TrackEndEvent,
        TrackStuckEvent,
        TrackExceptionEvent,
        WebSocketClosedEvent
    }
}