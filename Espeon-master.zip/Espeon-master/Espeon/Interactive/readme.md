﻿ All code under Espeon.Interactive is using
 Discord.Addons.Interactive
 https://github.com/foxbot/Discord.Addons.Interactive