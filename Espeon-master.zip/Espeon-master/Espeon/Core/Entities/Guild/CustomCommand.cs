﻿namespace Espeon.Core.Entities.Guild
{
    public class CustomCommand
    {
        public string CommandName { get; set; }
        public string CommandValue { get; set; }
    }
}
