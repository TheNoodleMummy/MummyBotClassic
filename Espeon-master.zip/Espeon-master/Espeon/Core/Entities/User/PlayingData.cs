﻿using System;

namespace Espeon.Core.Entities.User
{
    public class PlayingData
    {
        public int Location { get; set; }
        public DateTime LastMoved { get; set; }
    }
}
