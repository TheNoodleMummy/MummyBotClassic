﻿namespace Espeon.Helpers
{
    public static class ConstantsHelper
    {
        public static string BotToken;
        public static string GiphyToken;
        public static int PokemonLimit;
    }
}
