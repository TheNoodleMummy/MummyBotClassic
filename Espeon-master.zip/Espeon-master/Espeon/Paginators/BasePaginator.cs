﻿namespace Espeon.Paginators
{
    public abstract class BasePaginator { }
}
