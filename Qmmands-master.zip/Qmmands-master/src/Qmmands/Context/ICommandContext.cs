﻿namespace Qmmands
{
    /// <summary>
    ///     The interface for custom command contexts.
    /// </summary>
    public interface ICommandContext
    { }
}